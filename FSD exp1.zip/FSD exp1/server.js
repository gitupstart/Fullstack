const http = require('http');
const myModule = require('./myModule'); 

const server = http.createServer((req, res) => {
    res.writeHead(200, { 'Content-Type': 'text/plain' });
    res.write(myModule.greet('Midhuna')); 
    res.write('\nSum: ' + myModule.add(10, 20)); 
    res.write('\nProduct: ' + myModule.multiply(10, 7)); 
    res.end();
});
server.listen(3000, () => {
    console.log('Server running at http://localhost:3000');
});
