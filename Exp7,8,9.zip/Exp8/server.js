const express = require('express');
const morgan = require('morgan');
const helmet = require('helmet');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();

// Middleware Setup
app.use(morgan('dev'));  // Logging HTTP requests
app.use(helmet());       // Security middleware
app.use(bodyParser.json());  // Parse JSON request bodies
app.use(cors());         // Enable CORS for cross-origin requests

// Sample Route
app.get('/', (req, res) => {
    res.send('Welcome to the Express Server with Third-Party Extensions!');
});

// API Route to test Body-Parser
app.post('/data', (req, res) => {
    res.json({ message: 'Data received successfully', data: req.body });
});

app.listen(3000, () => console.log('Server running on http://localhost:3000'));
