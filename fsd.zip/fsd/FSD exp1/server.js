// server.js
const http = require('http');
const myModule = require('./myModule');  // Import custom module

const server = http.createServer((req, res) => {
    res.writeHead(200, { 'Content-Type': 'text/plain' });
    res.write(myModule.greet('Kamalaselvi')); // Using the greet function
    res.write('\nSum: ' + myModule.add(10, 20)); // Using the add function
    res.write('\nProduct: ' + myModule.multiply(10, 7)); // Using the multiply function
    res.end();
});
server.listen(3000, () => {
    console.log('Server running at http://localhost:3000');
});
