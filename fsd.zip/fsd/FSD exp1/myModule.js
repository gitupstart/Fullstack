// myModule.js
exports.greet = function(name) {
    return `Hello, ${name}! Welcome to Node.js`;
};

exports.add = function(a, b) {
    return a + b;
};

exports.multiply = function(a, b) {
    return a * b;
};
