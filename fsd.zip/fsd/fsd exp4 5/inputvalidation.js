const express = require('express');
const { body, validationResult } = require('express-validator');
const app = express();  // Initialize the Express app
let users = [];
app.use(express.json());  // Middleware to parse JSON bodies
// GET request - Fetch all users
app.get('/users', (req, res) => {
    res.json(users);
});
// POST request - Add a new user with validation
app.post('/users', [
    body('name').isString().withMessage('Name must be a string'),
    body('age').isInt({ min: 1 }).withMessage('Age must be a positive integer'),
], (req, res) => {
    const errors = validationResult(req); // Check for validation errors
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }
    const newUser = req.body;
    // Add new user to the in-memory users array
    users.push(newUser);
    // Logic to save the user (or for now just log it)
    console.log('New user added:', newUser);

    res.status(201).json(newUser);
});
app.listen(3000, () => {
    console.log('Server running on port 3000');
});
