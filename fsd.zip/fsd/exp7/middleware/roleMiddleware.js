const jwt = require('jsonwebtoken');
const User = require('../models/Muser');
const checkRole = (requiredRole) => {
    return async (req, res, next) => {
        try {
            const token = req.header('Authorization')?.replace('Bearer ', '');
            if (!token) return res.status(401).json({ error: "Access denied. No token provided." });

            const decoded = jwt.verify(token, process.env.JWT_SECRET);
            const user = await User.findById(decoded.id);

            if (!user) return res.status(404).json({ error: "User not found." });

            // Check if user has the required role
            if (user.role !== requiredRole) {
                return res.status(403).json({ error: "Forbidden. You don't have permission to access this resource." });
            }

            // Attach user info to the request object
            req.user = user;
            next();  // Proceed to the next middleware or route handler
        } catch (error) {
            res.status(400).json({ error: "Invalid token." });
        }
    };
};
module.exports = checkRole;
