const express = require('express');
const checkRole = require('../middleware/roleMiddleware');
const router = express.Router();

router.get('/admin-dashboard', checkRole('admin'), (req, res) => {
    res.json({ message: "Welcome to the admin dashboard!" });
});

router.get('/user-dashboard', checkRole('user'), (req, res) => {
    res.json({ message: "Welcome to the user dashboard!" });
});

module.exports = router;
