const express = require('express');
const app = express();
const path = require('path');
// Set EJS as the template engine
app.set('view engine', 'pug');
app.set('views', path.join(__dirname, 'views'));
// Sample Data
const users = [
    { name: "Krittika", age: 20 },
    { name: "Prakash", age: 18 },
    { name: "Keerthana", age: 21 }
];
// Route to Render EJS Template
app.get('/users', (req, res) => {
    res.render('users', { users });
});
app.listen(3000, () => console.log('Server running on http://localhost:3000'));

