const fs = require('fs');
fs.readFile('data.json', 'utf8', (err, data) => {
    if (err) {
        console.log('Error reading file:', err);
        return;
    }
    let jsonData = JSON.parse(data);
    console.log('Original Data:', jsonData);
    // Modify JSON data
    jsonData.age = 40;
    fs.writeFile('data.json', JSON.stringify(jsonData, null, 2), (err) => {
        if (err) {
            console.log('Error writing file:', err);
            return;
        }
        console.log('Data updated successfully');
    });
});
