const express = require('express');
const app = express();
const path = require('path');

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

const users = [
    { name: "Krittika", age: 20 },
    { name: "Prakash", age: 18 },
    { name: "Keerthana", age: 21 }
];

app.get('/users', (req, res) => {
    res.render('users', { users });
});
app.listen(3000, () => console.log('Server running on http://localhost:3000'));

