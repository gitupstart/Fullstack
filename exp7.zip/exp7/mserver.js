const express = require('express');
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const cors = require('cors');
const authRoutes = require('./routes/mauthRoutes');
const protectedRoutes = require('./routes/protectedRoutes');  // Import the protected routes
dotenv.config();
const app = express();
app.use(express.json());
app.use(cors());
mongoose.connect(process.env.MONGO_URI)
    .then(() => console.log("MongoDB Connected"))
    .catch((err) => console.log(err));

app.use('/api/auth', authRoutes);
app.use('/api/protected', protectedRoutes);  // Use the protected routes
app.listen(process.env.PORT, () => console.log(`Server running on port ${process.env.PORT}`));
