const jsonData = '{"name": "John", "age": 20}';
const obj = JSON.parse(jsonData);
obj.city = "New York";
console.log(obj);
const updatedJsonData = JSON.stringify(obj);
console.log(updatedJsonData);
