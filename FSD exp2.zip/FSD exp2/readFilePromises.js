const fs = require('fs');
function readFileAsync(fileName) {
    return new Promise((resolve, reject) => {
        fs.readFile(fileName, 'utf8', (err, data) => {
            if (err) {
                reject(err);
            } else {
                resolve(data);
            }
        });
    });
}
readFileAsync('example.txt')
    .then(data => {
        console.log('File content:', data);
    })
    .catch(err => {
        console.log('Error reading file:', err.message);
    });
